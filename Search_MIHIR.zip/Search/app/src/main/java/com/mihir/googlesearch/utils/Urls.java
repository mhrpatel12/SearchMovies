package com.mihir.googlesearch.utils;

/**
 * Created by mihir on 28-07-2019.
 */

public class Urls {
    public static final String BASE_URL = "https://www.googleapis.com/";//put your base url here

    public static final String searchMovies = "customsearch/v1";//put your end point here

}
