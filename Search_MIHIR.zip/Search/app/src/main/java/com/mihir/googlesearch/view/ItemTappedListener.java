package com.mihir.googlesearch.view;

import com.mihir.googlesearch.model.SearchResponse.Item;

public interface ItemTappedListener {
    void itemTapped(Item item);
}
